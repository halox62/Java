package sudoku;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import strutture.PuntiDiScelta;

public class Sudoku extends Backtracking<PuntiDiScelta,Integer>{
	
	private Integer mappa[][];
	private int n,contaPunti,numeriInseriti;
	boolean fine=false;
	
	public Sudoku() {
		mappa=new Integer [9][9];
		for(int i=0;i<mappa.length;i++) {
			for(int j=0;j<mappa.length;j++) {
				mappa[i][j]=0;
			}
		}
		this.n=9;
	}
	
	
	public void imposta(int i, int j, int v) {
		if(v<1 || v>9)throw new IllegalArgumentException();
		if(mappa[i][j]!=0)throw new IllegalArgumentException();
		for(int h=0;h<mappa.length;h++) {
			if(mappa[i][h]==v) {
				System.out.println("elememto gia presente sulla riga");
				return;
			}
		}
		for(int h=0;h<mappa.length;h++) {
			if(mappa[h][j]==v) {
				System.out.println("elememto gia presente sulla colonna");
				return;
			}
		}
		int inizio=calcola(i);
		int inizio1=calcola(j);
		int fine=calcola(i)+3;
		int fine1=calcola(j)+3;
		for(int h=inizio;h<fine;h++) {
			for(int g=inizio1;g<fine1;g++) {
				if(mappa[h][g]==v) {
					System.out.println("Elemento gia presente nella matrice 3x3");
					return;
				}
			}
		}
		mappa[i][j]=v;	
		numeriInseriti++;
	}

	@Override
	protected boolean ultimaSoluzione() {
		if(fine)return true;
		return false;
	}//ultimaSoluzione
	
	@Override
	protected boolean assegnabile(PuntiDiScelta p, Integer numero) {
		if(mappa[p.getRiga()][p.getColonna()]==0) {
			if(giaPresente(p.getRiga(),p.getColonna(),numero))return false;
			for(int i=0;i<n;i++) {
				if(mappa[p.getRiga()][i]==numero) return false;
			}
			for(int j=0;j<n;j++) {
				if(mappa[j][p.getColonna()]==numero) return false;
			}
			return true;
		}
		return false;
	}
	
	private boolean giaPresente(Integer riga,Integer colonna,Integer numero) {
		int inizioRiga=calcola(riga);
		int inizioColonna=calcola(colonna);
		int fine=inizioRiga+3;
		int fine1=inizioColonna+3;
		for(int h=inizioRiga;h<fine;h++) {
			for(int g=inizioColonna;g<fine1;g++) {
				if(mappa[h][g]==numero) {
					return true;
				}
			}
		}
		return false;
	}
	
	private int calcola(int x) {
		if(x<3)return 0; 
		if(x>=3&&x<6)return 3; 
		if(x>=6&&x<9)return 6;
		return -1;
	}

	@Override
	protected void assegna( PuntiDiScelta p, Integer numero) {
			mappa[p.getRiga()][p.getColonna()]=numero;
			numeriInseriti++;
			
		
	}//assegna

	@Override
	protected void deassegna( PuntiDiScelta p, Integer numero ) {
		mappa[p.getRiga()][p.getColonna()]=0;
		numeriInseriti--;
	}//deassegna
	
	@Override
	protected void scriviSoluzione() {
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<mappa.length;i++) {
			for(int j=0;j<mappa.length;j++) {
				sb.append(mappa[i][j]);
				sb.append(",");
			}
			System.out.println(sb.toString());
			sb.delete(0, sb.length());
		}
		System.out.println("------------------------");	
	}

	@Override
	protected boolean esisteSoluzione() {
		for(int i=0;i<mappa.length;i++) {
			for(int j=0;j<mappa.length;j++) {
				if(mappa[i][j]==0)return false;
			}
		}
		fine=true;
		return true;
	}

	@Override
	protected PuntiDiScelta prossimoPuntoDiScelta(PuntiDiScelta p) {
		if (contaPunti>=n*n-1)
			throw new IllegalStateException();
		return cerca(p.getRiga(),p.getColonna());
	}
	
	public PuntiDiScelta cerca(int riga, int colonna) {
		if(mappa[riga][colonna]==0) {
			contaPunti++;
			PuntiDiScelta p=new PuntiDiScelta(riga,colonna);
			return p;
		}
		if(colonna==8&&riga<8) {
			riga++;
			colonna=0;
			return cerca(riga,colonna);
		}
		if(colonna<8) {
			colonna++;
		}
		return cerca(riga,colonna);
	}

	@Override
	protected boolean esisteProssimoPuntoDiScelta(PuntiDiScelta p) {
		for(int i=0;i<mappa.length;i++) {
			for(int j=0;j<mappa.length;j++) {
				if(mappa[i][j]==0)return true;
			}
		}
		return false;
	}

	@Override
	protected Collection<Integer> scelte( PuntiDiScelta p ){
		List<Integer> s=new ArrayList<>();
		for( int i=1; i<=n; ++i ) {
			s.add(i);
		}
		return s;
	}

	@Override
	public String toString() {
		StringBuilder sb=new StringBuilder();
		int conta=1;
		for(int i=0;i<mappa.length;i++) {
			for(int j=0;j<mappa.length;j++) {
				sb.append(mappa[i][j]);
				sb.append(",");
				if(conta==9) {
					sb.append("\n");
					conta=0;
				}
				conta++;
			}
		}
		return sb.toString();
		
	}
	
	public static void main(String args[]) {
		Sudoku s=new Sudoku();
		s.imposta(0, 0, 5);
		s.imposta(1, 0, 7);
		s.imposta(2, 0, 8);
		s.imposta(3, 0, 2);
		s.imposta(4, 0, 9);
		s.imposta(5, 0, 1);
		s.imposta(8, 0, 4);
		
		s.imposta(2, 1, 2);
		s.imposta(5, 1, 6);
		s.imposta(8, 1, 1);
		
		s.imposta(4, 2, 7);
		s.imposta(5, 2, 4);
		s.imposta(6, 2, 2);
		s.imposta(7, 2, 5);
		
		s.imposta(1, 3, 3);
		s.imposta(2, 3, 9);
		s.imposta(4, 3, 5);
		s.imposta(5, 3, 2);
		
		s.imposta(0, 4, 6);
		s.imposta(3, 4, 7);
		
		s.imposta(0, 5, 8);
		s.imposta(2, 5, 7);
		s.imposta(3, 5, 6);
		s.imposta(6, 5, 4);
		s.imposta(8, 5, 5);
		
		s.imposta(0, 6, 7);
		s.imposta(2, 6, 6);
		s.imposta(5, 6, 5);
		s.imposta(6, 6, 1);
		s.imposta(8, 6, 2);
		
		s.imposta(1, 7, 1);
		s.imposta(3, 7, 8);
		s.imposta(4, 7, 6);
		s.imposta(5, 7, 7);
		s.imposta(7, 7, 4);
		
		s.imposta(0, 8, 4);
		s.imposta(1, 8, 9);
		s.imposta(2, 8, 5);
		s.imposta(3, 8, 1);
		s.imposta(4, 8, 2);
		s.imposta(6, 8, 8);
		s.imposta(8, 8, 6);
		System.out.println(s.toString());
		s.risolvi(s.cerca(0, 0));
	}
}
